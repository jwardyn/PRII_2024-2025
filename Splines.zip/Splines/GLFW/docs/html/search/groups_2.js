var searchData=
[
  ['gamepad_20axes_0',['Gamepad axes',['../group__gamepad__axes.html',1,'']]],
  ['gamepad_20buttons_1',['Gamepad buttons',['../group__gamepad__buttons.html',1,'']]]
];
