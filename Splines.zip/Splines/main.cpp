#include "context_setup.h"
#include "functions.h"



int main(int, char**)
{
  
    ImGuiContext_OGL context;
    context.setup_and_show();

    Splines sp;
    
    
    while (!glfwWindowShouldClose(context.window))
    {
        context.new_frame();
        sp.bezier();
       
        sp.hermite_curve();
       
        context.render_frame();
    }

    return 0;
}